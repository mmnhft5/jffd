/* script.js */
document.getElementById('uploadForm').addEventListener('submit', async function (event) {
    event.preventDefault();
    const fileInput = document.getElementById('fileInput');
    const formData = new FormData();
    formData.append('file', fileInput.files[0]);

    const responseMessage = document.getElementById('responseMessage');
    responseMessage.textContent = "جاري رفع الصورة...";
    responseMessage.style.color = '#007bff';

    try {
        const response = await fetch('/upload', {
            method: 'POST',
            body: formData,
        });

        const result = await response.json();
        if (response.ok) {
            responseMessage.textContent = "شكرًا لاستخدامكم خدمتنا! تم رفع الصورة بنجاح.";
            responseMessage.style.color = 'green';
        } else {
            responseMessage.textContent = result.error;
            responseMessage.style.color = 'red';
        }
    } catch (error) {
        responseMessage.textContent = "حدث خطأ. يرجى المحاولة مرة أخرى.";
        responseMessage.style.color = 'red';
    }
});